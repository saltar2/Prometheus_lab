#!/bin/bash

Parámetros pasados desde Nagios
HOSTNAME=$1
SERVICEDESC=$2
SERVICESTATE=$3
SERVICEOUTPUT=$4

Comprobamos si el estado del servicio es CRITICAL o WARNING
if [ "$SERVICESTATE" == "CRITICAL" ] || [ "$SERVICESTATE" == "WARNING" ]; then
    # Enviar una alerta de estado fallido (por ejemplo, usando un webhook de Discord)
    curl -X POST https://discord.com/api/webhooks/1349785711204634724/qX0nQbeXUFl2vw_u25ZnFQ2QXMWIMINSR6iCVAeAy2a0q499V8NDgtXRhk09u4xmqQip \
         -H "Content-Type: application/json" \
         -d '{
               "content": "Alerta de Nagios: El servicio '"$SERVICEDESC"' en el host '"$HOSTNAME"' ha fallado. Estado: '"$SERVICESTATE"'. Salida: '"$SERVICEOUTPUT"'."
             }'
fi