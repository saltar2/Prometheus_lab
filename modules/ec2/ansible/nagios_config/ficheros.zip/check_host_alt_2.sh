#!/bin/bash
# check_https_rta.sh
# Este script verifica la disponibilidad de un servicio HTTPS en el puerto 443
# del host especificado, accediendo a una ruta configurable.
#
# Imprime:
#   OK - Packet loss = 0%, RTA = <tiempo> ms   si se recibe HTTP 200 (tras redirección)
#   CRITICAL - Received HTTP <código>            en otro caso
#
# Uso: check_https_rta.sh <host_address> [endpoint]
# Si no se especifica un endpoint, se utiliza "nagiosadmin" por defecto.

if [ "$#" -lt 1 ]; then
    echo "Usage: $0 <host_address> [endpoint]"
    exit 3
fi

HOSTADDRESS="$1"

# Si se proporciona un endpoint, se usa; de lo contrario, se usa el valor por defecto.
if [ "$#" -ge 2 ]; then
    ENDPOINT="$2"
else
    ENDPOINT="nagiosadmin"
fi

URL="https://myapp.${HOSTADDRESS}/${ENDPOINT}"

# Usamos curl con -L para seguir redirecciones y obtener el estado final.
OUTPUT=$(/usr/bin/curl -L --max-time 10 -s -o /dev/null -w "%{http_code} %{time_total}" -u "nagiosadmin:campusdual" "$URL")
HTTP_CODE=$(echo "$OUTPUT" | awk '{print $1}')
TIME_TOTAL=$(echo "$OUTPUT" | awk '{print $2}')

if [ "$HTTP_CODE" = "200" ]; then
    # Convertir segundos a milisegundos.
    RESPONSE_TIME_MS=$(awk "BEGIN {printf \"%.2f\", $TIME_TOTAL * 1000}")
    echo "OK - Packet loss = 0%, RTA = ${RESPONSE_TIME_MS} ms"
    exit 0
else
    echo "CRITICAL - Received HTTP $HTTP_CODE"
    exit 2
fi